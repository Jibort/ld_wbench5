// ld_stream_listener_mixin.dart
// Oïdor de sobres d'un emissor d'stream.
// CreatedAt: 2025/02/11 ds. JIQ


import 'dart:async';

import 'package:ld_wbench5/03_core/ld_model.dart';
import 'package:ld_wbench5/03_core/streams/stream_envelope.dart';

/// Oïdor de sobres d'un emissor d'stream.
mixin StreamListenerMixin<E extends StreamEnvelope<M>, M extends LdModel> {
  // 🧩 MEMBRES ------------------------
  late final StreamSubscription<E>? sLstn;

  // ⚙️📍 FUNCIONALITAT ABSTRACTA ------
  void listened(E pEnvelope);
  // void Function(E pEnvelope)? listened;

  void onError(Object error, StackTrace stackTrace);
  // void Function(Object error, StackTrace stackTrace)? onError;
  
  void onDone();
  // void Function()? onDone;
}