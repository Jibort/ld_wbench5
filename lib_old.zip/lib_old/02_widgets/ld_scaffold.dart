// ld_scaffold.dart
// Widget principal de cada pàgina.
// CreatedAt: 2025/02/09 dc. JIQ

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:ld_wbench5/03_core/ld_model.dart';
import 'package:ld_wbench5/03_core/streams/stream_envelope.dart';
import 'package:ld_wbench5/03_core/widgets/ld_widget.dart';
import 'package:ld_wbench5/10_tools/ld_map.dart';
import 'ld_app_bar.dart';
import 'package:ld_wbench5/10_tools/debug.dart';

class LdScaffold
extends LdWidget {
  // 📦 MEMBRES ESTÀTICS ---------------
  static final String className = "LdScaffold";
  
  // 🧩 MEMBRES ------------------------
  
  // 🛠️ CONSTRUCTORS/CLEANERS ---------
  LdScaffold({ 
    required super.key, 
    required super.pView,
    required String pTitle,
    String? pSubTitle })
 {  wModel = LdScaffoldModel(pView: view, pWidget: this);
    wCtrl = LdScaffoldCtrl(
      pView: view, 
      pWidget: this,
    );
  }

  /// 📍 'ldTagMixin': Retorna la base del tag a fer servir en cas que no es proporcioni cap.
  @override String baseTag() => LdScaffold.className;

  /// 📍 'StatefulWidget': Retorna el controlador del Widget.
  @override
  LdWidgetCtrl<LdScaffoldCtrl, LdScaffold> createState()  => super.wCtrl;

  @override
  StreamSubscription<StreamEnvelope<LdModel>>? sLstn;

  @override
  StreamSubscription<StreamEnvelope<LdModel>>? vSub;

  @override
  void listened(StreamEnvelope<LdModel> pEnv) {
    // TODO: implement listened
  }

  @override
  void onDone() {
    // TODO: implement onDone
  }

  @override
  void onError(Object pError, StackTrace pSTrace) {
    // TODO: implement onError
  }

  // 🪟 GETTERS I SETTERS --------------
}

/// Model de dades del widget LdButton.
class   LdScaffoldModel
extends LdWidgetModel {
  // 📦 MEMBRES ESTÀTICS ---------------
  static final String className = "LdScaffoldModel";
  
  // 🧩 MEMBRES ------------------------

  // 🛠️ CONSTRUCTORS/CLEANERS ---------
  LdScaffoldModel({ 
    required super.pView, 
    required super.pWidget });

  @override
  LdMap toMap() => LdMap(pMap: {
    mfTag: tag
  });

  // 🪟 GETTERS I SETTERS --------------
  /// Retorna el text del butó.
  String? get text => _text.get();
  /// Estableix el text del butó.
  void set text(String? pText)
  => (text != pText) ? wCtrl.setState(() => text = pText): null;

  @override
  void fromMap(LdMap pMap) {
    _text.set(pMap[mfText]);
  }

  // 📍 IMPLEMENTACIÓ ABSTRACTA -------
  // 📍 'LdTagMixin': Retorna el tab base per defecte de la classe.
  @override String baseTag() => LdButtonModel.className;
  
  /// Retorna el valor d'un component donat o null.
  @override
  dynamic getField(String pField) 
  => (pField == mfText)
   ? _text.get()
   : null;


  /// Estableix el valor d'un component donat del model.
  @override
  void setField(String pField, dynamic pValue) 
  => (pField == mfText)
    ? wCtrl.setState(() { _text.set(pValue); })
    : null;
    
  @override
  void fromJson(String pJSon) => fromMap(LdMap(pMap: jsonDecode(pJSon)));
    
  @override
  String toJson() => jsonEncode(toMap);

  @override String modelName() => "wmnLdButton";
}

class   LdScaffoldCtrl 
extends LdWidgetCtrl<LdScaffold> {
  // 📦 MEMBRES ESTÀTICS ---------------
  static final String className = "LdScaffoldCtrl";
  
  // 🧩 MEMBRES ------------------------
  final LdAppBar _appBar;
  
  // 🛠️ CONSTRUCTORS/CLEANERS ---------
  LdScaffoldCtrl({ 
    required super.pView, 
    required super.pWidget,
    String? pTag,
    required String pTitle,
    String? pSubTitle })
    : _appBar = LdAppBar(
        key:       null, 
        pView:     view, 
        pTitle:    pTitle, 
        pSubTitle: pSubTitle,
      );

  /// 📍 'ldTagMixin': Retorna la base del tag a fer servir en cas que no es proporcioni cap.
  @override String baseTag() => LdScaffoldCtrl.className;

  // ♻️ CLICLE DE VIDA ----------------
  /// 📍 'LdOnDisposableIntf': Called when this object is removed from the tree permanently.
  @override
  void onDispose() {
    Debug.info("[$tag.onDispose()]: Instància completament eliminada.");
    super.onDispose();
  }
  
  /// 📍 'LdCtrlLifecycleIntf': Equivalent a deactivate
  @override
  void onDeactivate() {
    Debug.info("[$tag.onDeactivate()]: Instància eliminada de l'arbre.");
  }

  /// 📍 'LdCtrlLifecycleIntf': Equivalent a initState
  @override
  void onInit() {
    Debug.info("[$tag.onInit()]: Instància insertada a l'arbre.");
  }

  /// 📍 'LdCtrlLifecycleIntf': Equivalent a didChangeDependencies
  @override
  void onDependenciesResolved() {
    Debug.info("[$tag.onDependenciesResolved()]: Dependència actualitzada.");
  }

  /// 📍 'LdCtrlLifecycleIntf': Opcional, notifica quan la vista ha estat construïda.
  @override
  void onRendered(BuildContext pBCtx) {
    Debug.info("[$tag.onInit()]: Instància insertada a l'arbre.");
  }


  /// 📍 'LdCtrlLifecycleIntf': Equivalent a didUpdateWidget
  @override
  void onWidgetUpdated(covariant LdScaffold pOldWidget) {
    widget = pOldWidget;
    Debug.info("[$tag.onInit()]: Instància insertada a l'arbre.");
  }
  
  // ⚙️📍 FUNCIONALITAT ----------------
  /// Creació de tot l'arbre de components de 'LdAppbar'.
  @override
  Widget buildWidget(BuildContext pBCtx) 
    => Scaffold(
        key: null,      
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(kToolbarHeight + 20.0),
          child: _appBar,
        ),
    );
}
