// ld_widget.dart
// Abstracció de tots els widgets fets servir per l'aplicació.
// CreatedAt 2025/04/13 dl. JIQ

import 'package:flutter/material.dart';

import 'ld_widget_ctrl.dart';
import 'ld_widget_model.dart';
import 'package:ld_wbench5/03_core/interfaces/ld_widget_intf.dart';
import 'package:ld_wbench5/03_core/ld_bindings.dart';
import 'package:ld_wbench5/03_core/mixins/ld_tag_mixin.dart';
import 'package:ld_wbench5/03_core/views/ld_view.dart';
import 'package:ld_wbench5/10_tools/once_set.dart';

export 'ld_widget_ctrl.dart';

/// Abstracció de tots els widgets fets servir per l'aplicació.
abstract   class LdWidget<M extends LdWidgetModel, C extends LdWidgetCtrl>
extends    StatefulWidget 
with       LdTagMixin
implements LdWidgetIntf {
  // 📦 MEMBRES ESTÀTICS ---------------
  static final String className = "LdWidget";
  
  // 🧩 MEMBRES ------------------------
  /// Vista on pertany el wdiget.
  final LdView     _view;
  final OnceSet<M> _model = OnceSet<M>();

  /// Instància del controlador del widget.
  final OnceSet<LdWidgetCtrl> _ctrl = OnceSet<LdWidgetCtrl>();

  // 🛠️ CONSTRUCTORS/CLEANERS --------- 
  LdWidget({ super.key, required LdView pView, String? pTag, required M pModel })
  : _view  = pView
  { _model.set(pModel);
    registerTag(pTag: pTag, pInst: this);
  }
 
  @override void dispose() {
    LdBindings.remove(tag);
    super.dispose();
  }

  // 🪟 GETTERS I SETTERS --------------
    /// Retorna la vista on pertany el widget.
    @override LdView get view => _view;

  /// Retorna la vista on pertany el widget.
  @override LdWidgetCtrl get wCtrl => _ctrl.get(pError: "El controlador del widget encara no s'ha assignat!");

  /// Estableix la vista on pertany el widget.
  set wCtrl(LdWidgetCtrl pCtrl) => _ctrl.set(pCtrl, pError: "El controlador del widget ja estava assignat!");

  /// Retorna el model del widget.
  M get model => _model;
  set model(M pModel) => _model = pModel;
}

