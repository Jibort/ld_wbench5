// ld_widget_ctrl.dart
// Abstracció del controlador per a un widget de l'aplicació.
// CreatedAt: 2025/04/07 dl. JIQ

import 'package:flutter/material.dart';
import 'package:ld_wbench5/03_core/interfaces/ld_ctrl_lifecicle.dart';
import '../ld_ctrl.dart';
import '../views/ld_view.dart';
import 'ld_widget.dart';
import 'ld_widget_model.dart';

/// Abstracció del controlador per a un widget de l'aplicació.
abstract class LdWidgetCtrl<
  W extends LdWidget<LdWidgetModel, LdWidgetCtrl<W, M>>,
  M extends LdWidgetModel> 
extends    LdCtrl<LdWidget>  
implements LdCtrlLifecycleIntf<LdWidget> {
  // 📦 MEMBRES ESTÀTICS ---------------
  static final String className = "LdWidgetCtrl";
  
  // 🧩 MEMBRES ------------------------
  final LdView  _view;
  W             _widget;
  bool          _isEnabled;
  bool          _isVisible;
  bool          _isFocusable;


  // 🛠️ CONSTRUCTORS/CLEANERS ---------
  LdWidgetCtrl({ 
    required LdView pView, 
    required W pWidget, 
    super.pTag,
    bool isEnabled   = true,
    bool isVisible   = true,
    bool isFocusable = true, })
  : _widget      = pWidget,
    _view        = pView,
    _isEnabled   = isEnabled,
    _isVisible   = isVisible,
    _isFocusable = isFocusable;

  @override
  void dispose() {
    super.dispose();
  }

  // 🪟 GETTERS I SETTERS --------------
  /// Retorna la vista on pertany el widget.
  LdView get view => _view;

  /// Retorna el Widget on pertany el controlador.
  @override W get widget => _widget;
  
  /// Actualitza el Widget on pertany el controlador.
  set widget(W pWidget)  => _widget = pWidget;
  
  /// Retorna el model associat al widget.
  M get model => view.model as M;
  
  // 🪟 GETTERS I SETTERS --------------
  bool get isEnabled => _isEnabled;
  set isEnabled(bool pIsEnabled) {
    if (_isEnabled != pIsEnabled) {
      setState(() => _isEnabled = pIsEnabled);
    }
  }

  bool get isVisible => _isVisible;
  set isVisible(bool pIsVisible) {
    if (_isVisible != pIsVisible) {
      setState(()  => _isVisible = pIsVisible);
    }
  }
  
  bool get isFocusable => _isFocusable;
  set isFocusable(bool pIsFocusable) {
    if (_isFocusable != pIsFocusable) {
      setState(()  => _isFocusable = pIsFocusable);
    }
  }

  // 📍 IMPLEMENTACIÓ ABSTRACTA -------
  /// 📍 'State': Describes the part of the user interface represented by this view.
  @override
  Widget build(BuildContext pBCtx) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      onRendered(pBCtx); 
    });

    return buildWidget(pBCtx);
  }

  // ⚙️📍 FUNCIONALITAT ----------------
  /// Creació de tot l'arbre de components del Widget.
  Widget buildWidget(BuildContext pBCtx);
}
