// ld_widget_model.dart
// Model bàsic per a tots els widgets de l'aplicació.
// CreatedAt: 2025/04/14 dg. JIQ

import '../ld_model.dart';
import 'ld_widget.dart';
import '../../10_tools/only_once.dart';

/// Model bàsic per a tots els widgets de l'aplicació.
abstract class LdWidgetModel
extends  LdModel {
  // 📦 MEMBRES ESTÀTICS ---------------
  static final String className = "LdWidgetModel";
  
  // 🧩 MEMBRES ------------------------
  final OnceSet<LdWidget> _widget = OnceSet<LdWidget>();
  
  // 🛠️ CONSTRUCTORS/CLEANERS ---------
  LdWidgetModel();
  
  // 🪟 GETTERS I SETTERS --------------
  LdWidgetCtrl<LdWidget, LdWidgetModel> get wCtrl => _widget.get().wCtrl;

}