// ld_widget.dart
// Abstracció de tots els serveis fets servir per l'aplicació.
// CreatedAt 2025/04/13 dl. JIQ

/// Abstracció de tots els serveis fets servir per l'aplicació.
abstract class LdService {
  // 📦 MEMBRES ESTÀTICS ---------------
  static final String className = "LdService";
  
  // 🛠️ CONSTRUCTORS/CLEANERS --------- 
  const LdService();

}

