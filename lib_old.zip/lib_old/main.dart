import 'package:flutter/material.dart';
import '03_core/app/sabina_app.dart';

void main() {
  runApp(SabinaApp.inst);
}