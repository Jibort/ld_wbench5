// lib/ui/widgets/ld_list/ld_list_ctrl.dart
// Fitxer per al widget Ld List
// Created: 2025/05/17 ds. GPT(JIQ)
