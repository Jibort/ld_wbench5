// lib/ui/widgets/ld_action_button/ld_action_button_ctrl.dart
// Fitxer per al widget Ld Action Button
// Created: 2025/05/17 ds. GPT(JIQ)
