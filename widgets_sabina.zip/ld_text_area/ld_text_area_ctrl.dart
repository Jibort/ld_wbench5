// lib/ui/widgets/ld_text_area/ld_text_area_ctrl.dart
// Fitxer per al widget Ld Text Area
// Created: 2025/05/17 ds. GPT(JIQ)
