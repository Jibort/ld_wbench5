// lib/ui/widgets/ld_foldable_container/ld_foldable_container_widget.dart
// Fitxer per al widget Ld Foldable Container
// Created: 2025/05/17 ds. GPT(JIQ)
