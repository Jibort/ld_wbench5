// lib/ui/widgets/ld_message/ld_message_ctrl.dart
// Fitxer per al widget Ld Message
// Created: 2025/05/17 ds. GPT(JIQ)
