// ld_service_intf.dart
// Interfície d'un servei de l'aplicació.
// CreatedAt: 2025/04/24 dj. JIQ


/// Interfície d'un servei de l'aplicació.
abstract class LdServiceIntf {
  // 📦 MEMBRES ESTÀTICS ---------------

  // 🧩 MEMBRES ------------------------

  // 🛠️ CONSTRUCTORS/CLEANERS ---------

  // 🪟 GETTERS I SETTERS --------------

  // 📍 MÈTODES/FUNCIONS ABSTRACTES ----

}