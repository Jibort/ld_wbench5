// main.dart
// Entrada principal a l'aplicació Sabina.
// CreatedAt: 2025/04/21 dl. JIQ

import 'package:flutter/material.dart';
import '03_core/app/sabina_app.dart';

// Entrada principal a l'aplicació Sabina.
void main() => runApp(SabinaApp.inst);
