// lib/ui/widgets/ld_label/ld_label.dart  
// Widget per mostrar text estàtic amb suport per traduccions
// Created: 2025/05/06 dt. CLA
// Updated: 2025/05/14 dc. CLA[JIQ] - Aplicar traduccions automàtiques seguint l'arquitectura correcta

import 'package:flutter/material.dart';

import 'package:ld_wbench5/core/ld_widget/ld_widget_abs.dart';
import 'package:ld_wbench5/core/ld_widget/ld_widget_ctrl_abs.dart';
import 'package:ld_wbench5/core/extensions/map_extensions.dart';
import 'package:ld_wbench5/ui/widgets/ld_label/ld_label_ctrl.dart';
import 'package:ld_wbench5/ui/widgets/ld_label/ld_label_model.dart';
import 'package:ld_wbench5/core/map_fields.dart';

export 'ld_label_ctrl.dart';
export 'ld_label_model.dart';


/// Widget per mostrar text estàtic amb suport per traduccions
class   LdLabel 
extends LdWidgetAbs {
  /// Constructor principal seguint l'arquitectura Three-Layer
  LdLabel({
    Key? key,
    String? tag,
    String? text,
    List<String>? pPosArgs,
    LdMap<String>? pNamedArgs,
  }) : super(
    pKey: key, 
    pTag: tag, 
    pConfig: {
      if (text != null)       cfLabel: text,
      if (pPosArgs != null)   cfPositionalArgs: pPosArgs,
      if (pNamedArgs != null) cfNamedArgs: pNamedArgs,
    } as LdMap
  );

  /// Constructor des de mapa (per nova arquitectura)
  LdLabel.fromMap(LdMap<dynamic> pConfig) : super(pConfig: pConfig);

  @override
  LdWidgetCtrlAbs createCtrl() => LdLabelCtrl(this);

  // ACCESSORS DELEGANT AL MODEL
  LdLabelModel? get labelModel => model as LdLabelModel?;
  String get text => labelModel?.text ?? "";
  String get translatedText => labelModel?.translatedText ?? "";
}