// lib/ui/widgets/ld_label/ld_label_model.dart
// Model per al widget LdLabel
// Created: 2025/05/06 dt. CLA 
// Updated: 2025/05/14 dc. CLA - Correcció completa seguint l'arquitectura Widget-Controller-Model i afegint suport per traduccions amb interpolació

import 'package:flutter/material.dart';

import 'package:ld_wbench5/core/ld_widget/ld_widget_model_abs.dart';
import 'package:ld_wbench5/core/map_fields.dart';
import 'package:ld_wbench5/core/extensions/map_extensions.dart';
import 'package:ld_wbench5/core/extensions/string_extensions.dart';
import 'package:ld_wbench5/ui/widgets/ld_label/ld_label.dart';
import 'package:ld_wbench5/utils/debug.dart';

/// Model per al widget LdLabel
class   LdLabelModel 
extends LdWidgetModelAbs<LdLabel> {
  // MEMBRES ==============================================
  /// Text de l'etiqueta (clau de traducció o text directe)
  String _text = '';
  String get text => _text;
  set text(String value) {
    if (_text != value) {
      notifyListeners(() {
        _text = value;
        Debug.info("$tag: Text canviat a '$value'");
      });
    }
  }
  
  /// Paràmetres posicionals per a la traducció {0}, {1}, etc.
  List<String>? _positionalArgs;
  List<String>? get positionalArgs => _positionalArgs;
  set positionalArgs(List<String>? value) {
    if (_positionalArgs != value) {
      notifyListeners(() {
        _positionalArgs = value;
        Debug.info("$tag: Paràmetres posicionals canviats");
      });
    }
  }
  
  /// Paràmetres nomenats per a la traducció {name}, {count}, etc.
  LdMap<String>? _namedArgs;
  LdMap<String>? get namedArgs => _namedArgs;
  set namedArgs(LdMap<String>? value) {
    if (_namedArgs != value) {
      notifyListeners(() {
        _namedArgs = value;
        Debug.info("$tag: Paràmetres nomenats canviats");
      });
    }
  }
  
  /// Estil del text
  TextStyle? _textStyle;
  TextStyle? get textStyle => _textStyle;
  set textStyle(TextStyle? value) {
    if (_textStyle != value) {
      notifyListeners(() {
        _textStyle = value;
        Debug.info("$tag: Estil de text canviat");
      });
    }
  }
  
  /// Alineació del text
  TextAlign? _textAlign;
  TextAlign? get textAlign => _textAlign;
  set textAlign(TextAlign? value) {
    if (_textAlign != value) {
      notifyListeners(() {
        _textAlign = value;
        Debug.info("$tag: Alineació canviada a $value");
      });
    }
  }
  
  /// Comportament de desbordament
  TextOverflow? _overflow;
  TextOverflow? get overflow => _overflow;
  set overflow(TextOverflow? value) {
    if (_overflow != value) {
      notifyListeners(() {
        _overflow = value;
        Debug.info("$tag: Desbordament canviat a $value");
      });
    }
  }
  
  /// Nombre màxim de línies
  int? _maxLines;
  int? get maxLines => _maxLines;
  set maxLines(int? value) {
    if (_maxLines != value) {
      notifyListeners(() {
        _maxLines = value;
        Debug.info("$tag: Línies màximes canviades a $value");
      });
    }
  }
  
  /// Si el text pot ajustar-se suaument
  bool? _softWrap;
  bool? get softWrap => _softWrap;
  set softWrap(bool? value) {
    if (_softWrap != value) {
      notifyListeners(() {
        _softWrap = value;
        Debug.info("$tag: Ajust suau canviat a $value");
      });
    }
  }
  
  // CONSTRUCTORS/DESTRUCTORS =============================
  /// Constructor des d'un mapa - seguint el patró correcte
  LdLabelModel.fromMap(LdMap<dynamic> pMap) : super.fromMap(pMap) {
    // Carregar propietats específiques de LdLabelModel
    _loadFromMap(pMap);
    Debug.info("$tag: Model d'etiqueta creat des de mapa");
  }
  
  /// Constructor alternatiu per compatibilitat
  LdLabelModel.forWidget(LdLabel widget, LdMap<dynamic> pMap) 
    : super.forWidget(widget, pMap) {
    _loadFromMap(pMap);
    Debug.info("$tag: Model d'etiqueta creat per widget");
  }
  
  /// Carrega les propietats des d'un mapa
  void _loadFromMap(LdMap<dynamic> pMap) {
    // Propietats de configuració UI (cf*)
    _text = pMap[cfLabel] as String? ?? '';
    
    // Carregar paràmetres de traducció si existeixen
    if (pMap[cfPositionalArgs] != null) {
      _positionalArgs = List<String>.from(pMap[cfPositionalArgs]);
    }
    
    if (pMap[cfNamedArgs] != null) {
      _namedArgs = LdMap<String>();
      final sourceMap = pMap[cfNamedArgs] as Map;
      sourceMap.forEach((key, value) {
        _namedArgs![key.toString()] = value.toString();
      });
    }
    
    // Carregar propietats d'estil
    _textAlign = _parseTextAlign(pMap[cfTextAlign] as String?);
    _overflow = _parseTextOverflow(pMap[cfOverflow] as String?);
    _maxLines = pMap[cfMaxLines] as int?;
    _softWrap = pMap[cfSoftWrap] as bool?;
    
    Debug.info("$tag: Propietats carregades - text='$_text', textAlign=$_textAlign, maxLines=$_maxLines");
  }
  
  /// Converteix string a TextAlign
  TextAlign? _parseTextAlign(String? value) {
    if (value == null) return null;
    switch (value.toLowerCase()) {
      case 'left': return TextAlign.left;
      case 'right': return TextAlign.right;
      case 'center': return TextAlign.center;
      case 'justify': return TextAlign.justify;
      case 'start': return TextAlign.start;
      case 'end': return TextAlign.end;
      default: return null;
    }
  }
  
  /// Converteix string a TextOverflow
  TextOverflow? _parseTextOverflow(String? value) {
    if (value == null) return null;
    switch (value.toLowerCase()) {
      case 'clip': return TextOverflow.clip;
      case 'fade': return TextOverflow.fade;
      case 'ellipsis': return TextOverflow.ellipsis;
      case 'visible': return TextOverflow.visible;
      default: return null;
    }
  }
  
  // TRADUCCIÓ ============================================
  /// Obtenir el text traduït amb tots els paràmetres
  String get translatedText {
    if (_positionalArgs != null && _namedArgs != null) {
      return _text.txFull(_positionalArgs!, _namedArgs!);
    } else if (_positionalArgs != null) {
      return _text.txWith(_positionalArgs!);
    } else if (_namedArgs != null) {
      return _text.txArgs(_namedArgs!);
    } else {
      return _text.tx;
    }
  }
  
  // MAPEJAT ==============================================
  @override
  void fromMap(LdMap<dynamic> pMap) {
    super.fromMap(pMap);
    _loadFromMap(pMap);
  }
  
  @override
  LdMap<dynamic> toMap() {
    final map = super.toMap();
    
    // Afegir propietats de configuració (cf*)
    map[cfLabel] = _text;
    
    if (_positionalArgs != null) {
      map[cfPositionalArgs] = _positionalArgs;
    }
    if (_namedArgs != null) {
      map[cfNamedArgs] = _namedArgs;
    }
    if (_textAlign != null) {
      map[cfTextAlign] = _textAlign.toString().split('.').last;
    }
    if (_overflow != null) {
      map[cfOverflow] = _overflow.toString().split('.').last;
    }
    if (_maxLines != null) {
      map[cfMaxLines] = _maxLines;
    }
    if (_softWrap != null) {
      map[cfSoftWrap] = _softWrap;
    }
    
    return map;
  }
  
  @override
  dynamic getField({required String pKey, bool pCouldBeNull = true, String? pErrorMsg}) {
    switch (pKey) {
      case cfLabel: return _text;
      case cfPositionalArgs: return _positionalArgs;
      case cfNamedArgs: return _namedArgs;
      case cfTextAlign: return _textAlign;
      case cfOverflow: return _overflow;
      case cfMaxLines: return _maxLines;
      case cfSoftWrap: return _softWrap;
      default: return super.getField(
        pKey: pKey,
        pCouldBeNull: pCouldBeNull,
        pErrorMsg: pErrorMsg
      );
    }
  }
  
  @override
  bool setField({required String pKey, dynamic pValue, bool pCouldBeNull = true, String? pErrorMsg}) {
    switch (pKey) {
      case cfLabel:
        if (pValue is String || (pValue == null && pCouldBeNull)) {
          text = pValue as String? ?? '';
          return true;
        }
        break;
        
      case cfPositionalArgs:
        if (pValue is List<String> || (pValue == null && pCouldBeNull)) {
          positionalArgs = pValue as List<String>?;
          return true;
        }
        break;
        
      case cfNamedArgs:
        if (pValue is LdMap<String> || (pValue == null && pCouldBeNull)) {
          namedArgs = pValue as LdMap<String>?;
          return true;
        }
        break;
        
      case cfTextAlign:
        if (pValue is TextAlign || (pValue == null && pCouldBeNull)) {
          textAlign = pValue as TextAlign?;
          return true;
        } else if (pValue is String) {
          textAlign = _parseTextAlign(pValue);
          return true;
        }
        break;
        
      case cfOverflow:
        if (pValue is TextOverflow || (pValue == null && pCouldBeNull)) {
          overflow = pValue as TextOverflow?;
          return true;
        } else if (pValue is String) {
          overflow = _parseTextOverflow(pValue);
          return true;
        }
        break;
        
      case cfMaxLines:
        if (pValue is int || (pValue == null && pCouldBeNull)) {
          maxLines = pValue as int?;
          return true;
        }
        break;
        
      case cfSoftWrap:
        if (pValue is bool || (pValue == null && pCouldBeNull)) {
          softWrap = pValue as bool?;
          return true;
        }
        break;
        
      default:
        return super.setField(
          pKey: pKey,
          pValue: pValue,
          pCouldBeNull: pCouldBeNull,
          pErrorMsg: pErrorMsg
        );
    }
    return false;
  }
  
  // VALIDACIÓ ============================================
  @override
  bool validate() {
    // Les etiquetes poden ser buides (per exemple, spacers)
    return super.validate();
  }
}