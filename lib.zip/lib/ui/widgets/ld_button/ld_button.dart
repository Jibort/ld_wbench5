// lib/ui/widgets/ld_button/ld_button.dart
// Botó personalitzat de Sabina
// Created: 2025/04/29 DT. CLA[JIQ]
// Updated: 2025/05/13 dl. GPT(JIQ) - Imports i estil actualitzats

import 'package:flutter/material.dart';
import 'package:get/get_utils/get_utils.dart';

import 'package:ld_wbench5/core/ld_widget/ld_widget_abs.dart';
import 'package:ld_wbench5/core/ld_widget/ld_widget_ctrl_abs.dart';
import 'package:ld_wbench5/core/map_fields.dart';
import 'package:ld_wbench5/services/L.dart';
import 'package:ld_wbench5/ui/ui_consts.dart';
import 'package:ld_wbench5/ui/widgets/ld_button/ld_button_ctrl.dart';
import 'package:ld_wbench5/ui/widgets/ld_button/ld_button_model.dart';
import 'package:ld_wbench5/utils/debug.dart';
import 'package:ld_wbench5/core/extensions/map_extensions.dart';

class LdButton extends LdWidgetAbs {
  // CONSTRUCTOR PRINCIPAL =================================
  LdButton({
    Key? key,
    super.pTag,
    String? text = "",
    IconData? icon,
    VoidCallback? onPressed,
    ButtonStyle? style,
    bool isEnabled = true,
    bool isVisible = true,
  }) : super(pKey: key, pConfig: {
          cfTag: pTag ?? "LdButton_\${DateTime.now().millisecondsSinceEpoch}",
          cfIsVisible: isVisible,
          cfIsEnabled: isEnabled,
          cfButtonText: text,
          cfIcon: icon,
          cfButtonStyle: style,
          efOnPressed: onPressed,
        }) {
    Debug.info("\$tag: text pla: '$text', text traduït: '${(text??errInText).tx}'");
    Debug.info("\$tag: LdButton creat amb configuració");
  }

  // CONSTRUCTOR FROM MAP ==================================
  LdButton.fromMap(LdMap<dynamic> configMap)
      : super(pConfig: configMap) {
    Debug.info("\$tag: LdButton creat des d'un mapa");
  }

  // CONTROLADOR ASSOCIAT ==================================
  @override
  LdWidgetCtrlAbs createCtrl() {
    return LdButtonCtrl(this);
  }

  // ACCESSORS DE MODEL I CONTROLADOR ======================
  LdButtonModel? get model {
    final ctrl = wCtrl;
    if (ctrl is LdButtonCtrl) {
      return ctrl.model as LdButtonModel?;
    }
    return null;
  }

  LdButtonCtrl? get controller {
    final ctrl = wCtrl;
    if (ctrl is LdButtonCtrl) {
      return ctrl;
    }
    return null;
  }

  // GETTERS DE CONFIGURACIÓ ===============================
  String get text => config[cfButtonText] as String? ?? "";

  IconData? get icon => config[cfIcon] as IconData?;

  ButtonStyle? get style => config[cfButtonStyle] as ButtonStyle?;

  // ACCIÓ PROGRAMÀTICA =====================================
  void press() {
    controller?.press();
  }
}
